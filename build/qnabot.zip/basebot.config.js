"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports["default"] = void 0;var _basebotControllerWeb = _interopRequireDefault(require("basebot-controller-web"));
var _basebotStorageAzuretables = _interopRequireDefault(require("basebot-storage-azuretables"));
var _basebotLoggerDebug = _interopRequireDefault(require("basebot-logger-debug"));

var _basebotUtilQnamaker = _interopRequireDefault(require("basebot-util-qnamaker"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { "default": obj };}var _default =

{
  channels: [
  [
  _basebotControllerWeb["default"],
  {}]],


  storage: [
  [
  _basebotStorageAzuretables["default"],
  {}]],


  nlp: [],


  logger: [
  [
  _basebotLoggerDebug["default"],
  {}]],


  middleware: [
  [_basebotUtilQnamaker["default"], {}]] };exports["default"] = _default;
//# sourceMappingURL=basebot.config.js.map