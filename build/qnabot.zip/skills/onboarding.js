"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports["default"] = void 0;var _startCase = _interopRequireDefault(require("lodash/startCase"));
var _basebotLoggerDebug = _interopRequireDefault(require("basebot-logger-debug"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { "default": obj };}function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {try {var info = gen[key](arg);var value = info.value;} catch (error) {reject(error);return;}if (info.done) {resolve(value);} else {Promise.resolve(value).then(_next, _throw);}}function _asyncToGenerator(fn) {return function () {var self = this,args = arguments;return new Promise(function (resolve, reject) {var gen = fn.apply(self, args);function _next(value) {asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);}function _throw(err) {asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);}_next(undefined);});};}

var debug = (0, _basebotLoggerDebug["default"])('skills:onboarding', 'debug');
var error = (0, _basebotLoggerDebug["default"])('skills:onboarding', 'error');var _default =

[{
  event: 'conversationUpdate',
  handler: function () {var _handler = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(bot, message, controller) {var user;return regeneratorRuntime.wrap(function _callee$(_context) {while (1) {switch (_context.prev = _context.next) {case 0:_context.next = 2;return (
                controller.storage.users.get(message.user));case 2:user = _context.sent;
              debug("User = ", user);
              if (user && user.name) {
                bot.reply(message, {
                  text: "Hey ".concat(user.name, " \uD83D\uDC4B") });

              } else {
                controller.trigger('introduce', [bot, message, controller]);
              }case 5:case "end":return _context.stop();}}}, _callee);}));function handler(_x, _x2, _x3) {return _handler.apply(this, arguments);}return handler;}() },


{
  event: 'introduce',
  handler: function handler(bot, message, controller) {
    bot.startConversation(message, function (err, convo) {
      if (err) return error(err);
      convo.say({
        text: "Hey there! \uD83D\uDC4B \n\nI'm ".concat(process.env.BOT_NAME || 'Basebot', "."),
        typing: true });

      convo.ask("What's your name?'", function (response, convo) {
        var name = (0, _startCase["default"])(response.text);
        convo.setVar('name', name);
        controller.storage.users.save({
          id: message.user,
          name: name })["catch"](
        function (err) {return error(err);});
        convo.say({
          text: "Nice to meet you {{vars.name}}!" });

        convo.next();
      });
      convo.next();
      convo.addMessage("Didn't catch that. If you ever want to tell me again just say \"my name is ...\" or \"call me ...\" \uD83D\uDC4D", 'on_timeout');
    });
  } }];exports["default"] = _default;
//# sourceMappingURL=onboarding.js.map