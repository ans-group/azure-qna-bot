"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports["default"] = void 0;var _basebotLoggerDebug = _interopRequireDefault(require("basebot-logger-debug"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { "default": obj };}function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {try {var info = gen[key](arg);var value = info.value;} catch (error) {reject(error);return;}if (info.done) {resolve(value);} else {Promise.resolve(value).then(_next, _throw);}}function _asyncToGenerator(fn) {return function () {var self = this,args = arguments;return new Promise(function (resolve, reject) {var gen = fn.apply(self, args);function _next(value) {asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);}function _throw(err) {asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);}_next(undefined);});};}

var error = (0, _basebotLoggerDebug["default"])('skills:debug', 'error');var _default =

[{
  pattern: 'debug:attachments',
  handler: function handler(bot, message) {
    bot.reply(message, {
      text: 'here are some attachments',
      attachments: [{
        title: 'Gluten free Potato Cheese Sauce',
        thumb: 'https://dummyimage.com/75x75/0074c6/ffffff.png&text=Feb%2006',
        text: 'This is a delicious sauce for any occasion.',
        color: '#ff8817',
        image: 'https://www.edamam.com/web-img/86f/86fe08fb473e457428e529d580036f57',
        buttons: [{
          text: 'View Recipe',
          url: 'http://healthiersteps.com/gluten-free-potato-cheese-sauce/' },
        {
          text: 'Another Button',
          url: 'http://healthiersteps.com/gluten-free-potato-cheese-sauce/' }],

        values: [{
          type: 'icon',
          key: 'timer',
          value: '20 mins' },
        {
          type: 'icon',
          key: 'people',
          value: 'Serves 4' }] }] });



  } },

{
  pattern: 'debug:typing',
  handler: function () {var _handler = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(bot, message) {return regeneratorRuntime.wrap(function _callee$(_context) {while (1) {switch (_context.prev = _context.next) {case 0:
              bot.startConversation(message, function (err, convo) {
                if (err) return error(err);
                convo.say({
                  text: 'Hmm lemme just think for a second',
                  typing: true });

                convo.say({
                  text: "Okay, I'm done!",
                  delay: 5000 });

              });case 1:case "end":return _context.stop();}}}, _callee);}));function handler(_x, _x2) {return _handler.apply(this, arguments);}return handler;}() },


{
  event: 'debug:triggerFromNotification',
  handler: function handler(bot, message) {
    bot.reply(message, "Hey, it's me!");
  } },

{
  pattern: 'debug:suggestions',
  handler: function handler(bot, message) {
    bot.reply(message, {
      text: "Here's some suggestions",
      quick_replies: [{
        title: 'Hello',
        payload: 'Hello' },

      {
        title: 'Test',
        payload: 'Test' },

      {
        title: 'Card',
        payload: 'Card' },

      {
        title: 'It is time to go now',
        payload: 'Time to go' },

      {
        title: 'Goodbye',
        payload: 'Adios' }] });



  } }];exports["default"] = _default;
//# sourceMappingURL=debug.js.map