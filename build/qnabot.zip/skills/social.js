"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports["default"] = void 0;var _startCase = _interopRequireDefault(require("lodash/startCase"));function _interopRequireDefault(obj) {return obj && obj.__esModule ? obj : { "default": obj };}function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {try {var info = gen[key](arg);var value = info.value;} catch (error) {reject(error);return;}if (info.done) {resolve(value);} else {Promise.resolve(value).then(_next, _throw);}}function _asyncToGenerator(fn) {return function () {var self = this,args = arguments;return new Promise(function (resolve, reject) {var gen = fn.apply(self, args);function _next(value) {asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);}function _throw(err) {asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);}_next(undefined);});};}var _default =

[{
  intent: 'Social.Greeting',
  handler: function () {var _handler = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(bot, message, controller) {return regeneratorRuntime.wrap(function _callee$(_context) {while (1) {switch (_context.prev = _context.next) {case 0:
              controller.trigger('conversationUpdate', [bot, message, controller]);case 1:case "end":return _context.stop();}}}, _callee);}));function handler(_x, _x2, _x3) {return _handler.apply(this, arguments);}return handler;}() },


{
  pattern: 'Nice to meet you!',
  handler: function handler(bot, message) {
    bot.reply(message, 'Thanks 😁 you too!');
  } },

{
  pattern: ['what is my name', 'who am i'],
  handler: function () {var _handler2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(bot, message, controller) {var user;return regeneratorRuntime.wrap(function _callee2$(_context2) {while (1) {switch (_context2.prev = _context2.next) {case 0:_context2.next = 2;return (
                controller.storage.users.get(message.user));case 2:user = _context2.sent;
              if (user && user.name) {
                bot.reply(message, "You're ".concat(user.name, "! I'd never forget you \uD83D\uDE01"));
              } else {
                bot.reply(message, 'Not sure.. just say "Call me ..." to tell me your name');
              }case 4:case "end":return _context2.stop();}}}, _callee2);}));function handler(_x4, _x5, _x6) {return _handler2.apply(this, arguments);}return handler;}() },


{
  pattern: ['my name is ([A-Za-z\\s]*)', 'call me ([A-Za-z\\s]*)'],
  handler: function handler(bot, message, controller) {
    var name = (0, _startCase["default"])(message.match[1]);
    controller.storage.users.save({
      id: message.user,
      name: name })["catch"](
    function (err) {return error(err);});
    if (name) {
      bot.reply(message, "Great, I'll call you ".concat(name, " from now on \uD83D\uDE0A"));
    }
  } }];exports["default"] = _default;
//# sourceMappingURL=social.js.map