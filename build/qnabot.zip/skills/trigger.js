"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports["default"] = void 0;var _default = [{
  event: 'trigger',
  handler: function handler(bot, message, controller) {
    if (message.trigger) {
      controller.trigger(message.trigger, [bot, message, controller]);
    }
  } }];exports["default"] = _default;
//# sourceMappingURL=trigger.js.map