![ANS](./images/ans_logo_small.png)

# QnA Bot

For more information on the ANS Azure QnA Bot visit <https://www.ans.co.uk>

This Azure ARM template, will deploy a simple Azure QnA Bot into your Azure subscription using the ANS BaseBot application code.  

[![Deploy to Azure](./images/azure_deploy.png)](https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Fans-group%2Fbasebot-azure-qna-build%2Fmaster%2Ftemplate%2Fazuredeploy.json)
[![Deploy to Azure](./images/azure_view.png)](http://armviz.io/#/?load=https%3A%2F%2Fraw.githubusercontent.com%2Fans-group%2Fbasebot-azure-qna-build%2Fmaster%2Ftemplate%2Fazuredeploy.json)
