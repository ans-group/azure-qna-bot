"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports["default"] = void 0;var teamsRef = {};
var usersRef = {};
var channelsRef = {};

var driver = {
  teams: {
    get: get(teamsRef),
    save: save(teamsRef),
    all: all(teamsRef) },

  channels: {
    get: get(channelsRef),
    save: save(channelsRef),
    all: all(channelsRef) },

  users: {
    get: get(usersRef),
    save: save(usersRef),
    all: all(usersRef) } };var _default =


driver;exports["default"] = _default;

function get(storageRef) {
  return function (id) {return new Promise(function (resolve, reject) {
      resolve(storageRef[id] || {});
    });};
}

function save(storageRef) {
  return function (data) {return new Promise(function (resolve, reject) {
      storageRef[data.id] = data;
      resolve(data);
    });};
}

function all(storageRef) {
  return function () {return new Promise(function (resolve, reject) {
      resolve(storageRef);
    });};
}
//# sourceMappingURL=storage.js.map